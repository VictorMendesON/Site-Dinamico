<?php
    include "../adm/controle.php";
    include "../adm/seguranca_adm.php";
?>

<div class="row text-center quadro">
    <div class="col-12 col-md-6">
        <a href="../usuario/listar_usuario.php">
            <img src="../img/usuario.jfif" alt="">
            <p>USUARIOS </p>
        </a>
    </div>
    <div class="col-12 col-md-6">
        <a href="../produto/listar_produto.php">
            <img src="../img/produto.jpg" alt="">
            <p>PRODUTO</p>
        </a>
    </div>
</div>
     