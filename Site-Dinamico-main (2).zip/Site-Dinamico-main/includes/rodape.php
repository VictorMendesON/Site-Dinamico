
    <footer>
        <div class="rodape">
            <div>
                <h4>DESTAQUES</h4>
                <ul class="destque">
                    
                    <li><a href="#">Celulares</a></li>
                    <li><a href="#">TV's</a></li>
                    <li><a href="#">Notebooks</a></li>
                    <li><a href="#">PS5</a></li>
                    <li><a href="#">Pc gamer</a></li>
                </ul>
            </div>
            <div>
                <h4>A CARIOCATECH</h4>
                <ul class="cariocatech">
                    <li><a href="#">Sobre</a></li>
                    <li><a href="#">Política de privacidade</a></li>
                    <li><a href="#">Regras do site</a></li>
                </ul>
            </div>
        </div>
        <div id="rodape">
            <div><a href="#"><p>Fale conosco@cariocatech.com</p></a></div>
            <div><p>Endereço Rua Sacadura Cabral, 102 - Rio de Janeiro, RJ - 20081-902</p></div>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>
</html>