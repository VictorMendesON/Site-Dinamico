<?php 
$styles = array(
  0 => 'global.css',
  #1 => 'checkout.css',
  2 => 'header.css',
  3 => 'rodape.css',
);
include './head.php';
if(ISSET($_GET['id'])){
  require_once './includes/conexao.php';
  $id = $_GET['id'];
  $sql = "SELECT * FROM produtos WHERE id_produto = '$id';";
  $query = mysqli_fetch_array(mysqli_query($conexao, $sql));
  $img = $query['foto'];
}


/*curl --request POST \
     --url https://sandbox.api.pagseguro.com/oauth2/application \
     --header 'accept: application/json' \
     --header 'content-type: application/json'*/
?>
  <body class="bg-light">
  <?php include './includes/header.php';?>
    <div class="container pt-4">
      <div class="row">
        <div class="col-md-4 order-md-2 mb-4">
          <h4 class="d-flex justify-content-between align-items-center mb-3">
            <span class="text-muted">Seu carrinho</span>
            <span class="badge badge-secondary badge-pill">3</span>
          </h4>
          <ul class="list-group mb-3">
            <img src='./img/<?= $img ?>' class='list-group-item w-100' alt='imagem do produto'>
            <li class="list-group-item d-flex justify-content-between lh-condensed">
              <div>
                <h6 class="my-0"><?= $query['nome']?></h6>
              </div>
              <span class="text-muted">R$ <?= $query['preco']?>,00</span>
            </li>
            <li class="list-group-item d-flex justify-content-between">
              <span>Total:</span>
              <strong>R$ <?= $query['preco']?>,00</strong>
            </li>
          </ul>
        </div>
        <div class="col-md-8 order-md-1">
          <h4 class="mb-3">Página de compra</h4>
          <form class="needs-validation" novalidate>
            <div class="row">
              <div class="col-md-6 mb-3">
                <label for="firstName">Nome</label>
                <input type="text" class="form-control" id="firstName" placeholder="" value="" required>
                <div class="invalid-feedback">
                  Valid first name is required.
                </div>
              </div>
              <div class="col-md-6 mb-3">
                <label for="lastName">Sobrenome</label>
                <input type="text" class="form-control" id="lastName" placeholder="" value="" required>
                <div class="invalid-feedback">
                  Valid last name is required.
                </div>
              </div>
            </div>

            <div class="mb-3">
              <label for="username">CPF</label>
              <div class="input-group">
                <input type="text" class="form-control" id="username" placeholder="" required>
                <div class="invalid-feedback" style="width: 100%;">
                  Your CPF is required.
                </div>
              </div>
            </div>

            <div class="mb-3">
              <label for="email">Email <span class="text-muted">(Optional)</span></label>
              <input type="email" class="form-control" id="email" placeholder="">
              <div class="invalid-feedback">
                Please enter a valid email address for shipping updates.
              </div>
            </div>

            <div class="mb-3">
              <label for="address">Endereço</label>
              <input type="text" class="form-control" id="address" placeholder="" required>
              <div class="invalid-feedback">
                Please enter your shipping address.
              </div>
            </div>

            <div class="mb-3">
              <label for="address2">Complemento<span class="text-muted">(Opcional)</span></label>
              <input type="text" class="form-control" id="address2" placeholder="">
            </div>

            <div class="row">
              <div class="col-md-5 mb-3">
                <label for="country">Estado</label>
                <select class="custom-select d-block w-100" id="country" required>
                  <option value="">Escolher...</option>
                  <option>Rio de Janeiro</option>
                </select>
                <div class="invalid-feedback">
                  Please select a valid country.
                </div>
              </div>
              <div class="col-md-4 mb-3">
                <label for="state">Cidade</label>
                <select class="custom-select d-block w-100" id="state" required>
                  <option value="">Escolher...</option>
                  <option>Rio de Janeiro</option>
                </select>
                <div class="invalid-feedback">
                  Please provide a valid state.
                </div>
              </div>
              <div class="col-md-3 mb-3">
                <label for="zip">Zip</label>
                <input type="text" class="form-control" id="zip" placeholder="" required>
                <div class="invalid-feedback">
                  Zip code required.
                </div>
              </div>
            </div>
            <hr class="mb-4">
            <div class="custom-control custom-checkbox">
              <input type="checkbox" class="custom-control-input" id="same-address">
              <label class="custom-control-label" for="same-address">
                O endereço de entrega é o mesmo do meu endereço de cobrança</label>
            </div>
            <div class="custom-control custom-checkbox">
              <input type="checkbox" class="custom-control-input" id="save-info">
              <label class="custom-control-label" for="save-info">Salve esta informação para a próxima compra</label>
            </div>
            <hr class="mb-4">

            <h4 class="mb-3">Forma de pagamento</h4>

            <div class="d-block my-3">
              <div class="custom-control custom-radio">
                <input id="credit" name="paymentMethod" type="radio" class="custom-control-input" checked required>
                <label class="custom-control-label" for="credit">Cartão de crédito</label>
              </div>
              <div class="custom-control custom-radio">
                <input id="debit" name="paymentMethod" type="radio" class="custom-control-input" required>
                <label class="custom-control-label" for="debit">Cartão de débito</label>
              </div>
              <div class="custom-control custom-radio">
                <input id="paypal" name="paymentMethod" type="radio" class="custom-control-input" required>
                <label class="custom-control-label" for="paypal">Paypal</label>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 mb-3">
                <label for="cc-name">Nome do cartão</label>
                <input type="text" class="form-control" id="cc-name" placeholder="" required>
                <div class="invalid-feedback">
                  Name on card is required
                </div>
              </div>
              <div class="col-md-6 mb-3">
                <label for="cc-number">Número do cartão</label>
                <input type="text" class="form-control" id="cc-number" placeholder="" required>
                <div class="invalid-feedback">
                  Credit card number is required
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-3 mb-3">
                <label for="cc-expiration">Expira em</label>
                <input type="date" class="form-control" id="cc-expiration" placeholder="" required>
                <div class="invalid-feedback">
                  Expiration date required
                </div>
              </div>
              <div class="col-md-3 mb-3">
                <label for="cc-expiration">CVV</label>
                <input type="text" class="form-control" id="cc-cvv" placeholder="" required>
                <div class="invalid-feedback">
                  Security code required
                </div>
              </div>
            </div>
            <hr class="mb-4">
            <button class="btn btn-primary btn-lg btn-block" type="submit">Finalizar compra</button>
          </form>
        </div>
      </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js" integrity="sha384-qKXV1j0HvMUeCBQ+QVp7JcfGl760yU08IQ+GpUo5hlbpg51QRiuqHAJz8+BrxE/N" crossorigin="anonymous"></script>
  </body>
</html>